# 02 — Services, RPC & enforcement (Phase 2)

How the bridge orchestrates epochs, concurrency, coverage, and rate-limiting. None of this verifies crypto —
it is server-side concurrency/coverage/abuse control on top of opaque blobs.

---

## 1. Epoch bump points (BR-1)

The bridge increments `keyVersion` (and appends to `keyHistory`) on exactly these ops:
- `groupUpdate` whose resulting member set is **smaller** for any user/manager (a **removal**), or which the
  caller flags as a rotation;
- `generateNewGroupKey` (always).

It does **not** bump on a pure add (`groupUpdate` that only widens the set) — new members get the current
epoch. *(How does the bridge know it's a removal? Compare `oldGroup.users∪managers` vs the request's sets. A
removal = any prior member absent from the new sets. Alternatively require the client to pass an explicit
`rotate: boolean`; recommended to combine both — bump if removal **or** `rotate`.)*

---

## 2. `context.generateNewGroupKey` (BR-2)

New `@ApiMethod` on `ContextApi` + `GroupService.generateNewGroupKey`. Order of operations (in a transaction):

1. `validateContextSessionAndGetCloudUser()`; load `oldGroup` → `GROUP_DOES_NOT_EXIST`.
2. ACL `context/groupUpdate` (manager-only); **rate-limit** check (§4).
3. **CAS guard:** `if (oldGroup.keyVersion !== expectedKeyVersion) → ROTATED_ALREADY` (with winner envelope,
   §3).
4. Coverage: `cloudKeyService.checkKeysAndClients(...)` over the **unchanged** member set for the new `keyId`
   (members must all be re-covered).
5. `groupRepository.generateNewGroupKey(oldGroup, modifier, newGroupPubKey, data, keyId, keys, confirmationTag)`
   — atomic update: append a `history` entry (stores opaque `data`), set `groupPubKey = newGroupPubKey`,
   `keyVersion = oldGroup.keyVersion + 1`, push old pub to `keyHistory`.
6. Notify members (`groupUpdated`).

No membership change; the member sets are copied from `oldGroup`. The epoch is committed in the endpoint DIO
inside `data` (the bridge just stores it).

---

## 3. Optimistic CAS + `ROTATED_ALREADY` (BR-3)

Make the epoch the concurrency token on **every rotation path** (`generateNewGroupKey` and removal-bearing
`groupUpdate`):

```
GroupRepository.casRotate(id, expectedKeyVersion, newDoc):
   res = collection.findOneAndUpdate(
            { _id: id, keyVersion: expectedKeyVersion },        // atomic compare
            { $set: {... newDoc ...}, $inc: { keyVersion: 1 }, $push: { keyHistory: oldPub } },
            { returnNewDocument: true })
   if (res == null) return MISS                                  // someone else rotated first
   return res
```

On `MISS`, the service responds **`ROTATED_ALREADY`** whose payload includes the **winning epoch's group key
entry addressed to the caller**:

```ts
interface RotatedAlreadyData {
  keyVersion: number;                 // the winner's new epoch
  groupPubKey: types.cloud.GroupPubKey;
  winnerKeyEntry: types.cloud.KeyEntry;  // the winner's `keys[]` entry FOR THE CALLER (wrapped to caller's pubkey)
}
```

- The winner's `keys[]` (submitted with the winning rotation) already contains one entry per member; the
  bridge simply selects the caller's entry and returns it in the rejection.
- **Safety:** that entry is wrapped to the caller's pubkey and integrity-protected by the *winner's* DIO — a
  malicious bridge can neither forge nor substitute it (the endpoint verifies it on adopt). The bridge is just
  routing a blob it already holds.
- The loser adopts the new epoch key from the envelope and retries its original op — no extra round trip
  ([../endpoint_phase_two/02-rotation-cas-confirmation.md](../endpoint_phase_two/02-rotation-cas-confirmation.md)).

---

## 4. Rate-limit + manager-only rotation (BR-4)

- **Manager-only:** rotations already require `context/groupUpdate` ACL — keep it; reject member-role callers.
- **Rate-limit:** throttle rotations per `(groupId, actorUserId)` (e.g. token-bucket; reuse any existing
  bridge rate-limit middleware, otherwise a small per-group counter with a time window). Reject with a
  rate-limit error (or `ACCESS_DENIED` with a reason) when exceeded.
- **No client-arbitrary rotation:** the bridge bumps epochs only on hard roster changes (removal) or explicit
  `generateNewGroupKey` — never as an implicit side effect a member could spam. This defeats the rotation-spam
  DoS ([../group-mls-lite-plan.md](../group-mls-lite-plan.md) §5).

---

## 5. Per-epoch coverage on container re-key (BR-5)

The container re-key path (an ordinary container `*Update` that rotates `CK`) must, when the container grants
to groups, verify coverage **against the groups' current epoch**:

- Extend `CloudKeyService.checkGroupKeysAndGrantees` / `verifyThatOnlyGivenGroupsHaveAccess`: for each grantee
  group `g`, the submitted `groupKeys` entry must carry `groupEpoch == g.keyVersion` (the **current** epoch)
  and there must be exactly one entry per grantee for the new `keyId` (set-equality, as Phase 1) — no missing,
  no extra, no stale epoch.
- This prevents a malicious member from "re-keying" a container to an **old** group epoch (which a removed
  member could still read). Mismatch ⇒ `INVALID_PARAMS`.

The bridge fetches each grantee group's current `keyVersion` to compare. (One extra group read per re-key with
group grantees; index already covers it.)

---

## 6. `groupUpdate` (Phase-2 deltas to the Phase-1 method)

Phase-1 `groupUpdate` stays; Phase 2 adds:
1. detect removal ⇒ treat as a rotation: use the **CAS** (`expectedKeyVersion`) instead of (or in addition to)
   the `version` check, and bump `keyVersion`/`keyHistory`;
2. on CAS miss ⇒ `ROTATED_ALREADY` + winner envelope (§3);
3. rate-limit (§4).

Adds (no removal) keep the Phase-1 behaviour (no epoch bump; `version` optimistic-concurrency only).

> Note: `version` (= `history.length`) and `keyVersion` (= epoch) are **different** counters. `version`
> increments on *every* update; `keyVersion` only on rotations. Keep both: `version` for general
> last-writer-wins, `keyVersion` for the rotation CAS + epoch tagging.

---

## 7. IOC / wiring
`generateNewGroupKey` rides on the existing `ContextApi`/`GroupService` wiring (no new IOC service). Add the
validator entry (`ContextApiValidator`) and the client method (`ContextApiClient`). Rate-limit state can live
in the existing rate-limit subsystem or a small in-memory/Redis counter keyed by `(groupId, actor)`.
